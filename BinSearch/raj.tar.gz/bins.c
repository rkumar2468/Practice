#include<stdio.h>
#include<stdlib.h>

struct searchBin {
	int val;
	struct searchBin *right;
	struct searchBin *left;
};

typedef struct searchBin BinSearch;

BinSearch *createNode()
{
	BinSearch *ret = (BinSearch *)malloc(sizeof(BinSearch));
	ret->val = 0;
	ret->right=NULL;
	ret->left=NULL;
	return ret;
}

int insert(BinSearch *root, int val)
{
	int ret = 0;
	if(root == NULL) {
		printf("1\n");
		root = createNode();
		root->val = val;
		return val;
	} else {
		if(root->val == 0) {
			printf("1.1\n");
			root->val = val;
			return val;
		}
		else if(root->val > val) {
			printf("2\n");
			insert(root->left, val);
		}
		else if(root->val < val)
		{
			printf("3\n");
			insert(root->right, val);
		}
		ret = val;
	}
	return ret;
}

int search(BinSearch *b, int val)
{
	int ret = -1;
	if(b == NULL) { 
		printf("Null Value \n");
		return ret;
	}
	if(b->val == val) 
		return val;
	else if (b->val > val)
		ret = search(b->left, val);
	else
		ret = search(b->right, val);
	return ret;
}

int main(void)
{
	BinSearch *bi = createNode(); 
	int ret,a;
	printf("Inserting 4\n"); 
	insert(bi,4);
	printf("Inserting 40\n"); 
	insert(bi,40);
	printf("Inserting 3\n"); 
	insert(bi,3);
	printf("Inserting 31\n"); 
	insert(bi,31);
	printf("Enter the element to be searched: \n");
	scanf("%d",&a);
	ret = search(bi,a);
	if(ret < 0)
		printf("No such element in the binary tree %d\n",ret);
	else 
		printf("Value %d found in the tree.!!\n",a);
	return 0;
}	
